from .retriever import PersistentBM25Retriever
__version__ = "0.4"
